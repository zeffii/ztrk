// Generates a gendsp Buffer-decoder Codebox body from a params spec array.
// Each param entry: [type, "Name |(t:..., d:default, s:[lo,hi], dval:...)", group]
// type "b"  -> one-sample trigger pulse, no History
// anything else -> latched value, held in History, scaled from raw [0,1] to [lo,hi]

function parseMeta(metaPart) {
	const s = metaPart.trim().replace(/^\(|\)$/, '').replace(/\)$/, '');
	const t = (s.match(/t:([^,]+)/) || [, '']) [1].trim();
	const dRaw = (s.match(/d:([-\d.]+)/) || [, '0']) [1];
	const sMatch = s.match(/s:\[([^\]]+)\]/);
	const scale = sMatch ? sMatch[1].split(',').map(Number) : [0, 1];
	return { t, def: parseFloat(dRaw), scale };
}

function toVarName(name) {
	return '_' + name.trim().replace(/[^a-zA-Z]/g, '').toUpperCase();
}

function generateDecoder(params, opts = {}) {
	const { bufferName = 'buf', chParam = 'chIndex' } = opts;

	const parsed = params.map((p, i) => {
		const [type, desc] = p;
		const [namePart, metaPart] = desc.split('|');
		const name = namePart.trim();
		const meta = parseMeta(metaPart);
		return { index: i, type, name, varName: toVarName(name), ...meta };
	});

	const lines = [];
	lines.push(`Buffer ${bufferName};`);
	lines.push(`Param ${chParam}(0, min=0, max=${params.length * 2});`);
	lines.push('');
	lines.push(`History _GATEPREV(0);`);
	parsed.forEach(p => {
		if (p.t === 'trigger') return;
		lines.push(`History ${p.varName}(${p.def});`);
	});

	lines.push('');
	lines.push(`pindex = in1;`);
	lines.push(`trig = (in2 > 0.0);`);
	lines.push(`edge = trig && !_GATEPREV;`);
	lines.push(`_GATEPREV = trig;`);
	lines.push('');

	const fmt = n => parseFloat(n.toFixed(6));

	parsed.forEach((p, i) => {
		const outN = i + 1;
		const [lo, hi] = p.scale;
		const span = fmt(hi - lo);
		let expr;
		if (lo === 0 && hi === 1) expr = 'raw';
		else if (lo === 0) expr = `raw * ${span}`;
		else expr = `${fmt(lo)} + raw * ${span}`;

		lines.push(`// ${p.index} ${p.name}`);
		lines.push(`raw = peek(buf, pindex, ${chParam}+${p.index});`);
		if (p.t === 'trigger') {
			lines.push(`out${outN} = (edge && raw > 0.5) ? 1.0 : 0.0;`);
		} else {
			lines.push(`${p.varName} = (edge && raw >= 0.0) ? (${expr}) : ${p.varName};`);
			lines.push(`out${outN} = ${p.varName};`);
		}
		lines.push('');
	});

	return lines.join('\n');
}

const params = [
	['b', 'Trigger |(t:trigger, dval:.)', 0],
	["hh", "Drum Radius |(t:m, d:0.18, s:[0.05,0.4], dval:5F)", 1],
	["hh", "Drum Depth |(t:m, d:0.15, s:[0.03,0.5], dval:41)", 1],
	["hh", "Hit Radius |(t:m, d:0.09, s:[0,0.4], dval:39)", 1],
	["hh", "Vellum Thickness |(t:coeff, d:1.0, s:[0.2,2], dval:71)", 2],
	["hh", "Tightness |(t:coeff, d:0.6, s:[0,1], dval:99)", 2],
	["hh", "Tightness Env |(t:coeff, d:0.15, s:[0,1], dval:26)", 2],
	["hh", "Inflection |(t:coeff, d:0.5, s:[0,1], dval:80)", 2],
	["hh", "Membrane Damp |(t:coeff, d:0.35, s:[0,1], dval:59)", 2],
	["hh", "Stroke Intensity |(t:coeff, d:0.8, s:[0,1], dval:CC)", 3],
	["hh", "Stroke Linger |(t:coeff, d:0.12, s:[0,1], dval:1F)", 3],
	["hh", "Stroke Material |(t:coeff, d:0.5, s:[0,1], dval:80)", 3],
	["hh", "Beater Size |(t:coeff, d:0.3, s:[0,1], dval:4D)", 3],
	["hh", "Cavity Damp |(t:coeff, d:0.5, s:[0,1], dval:80)", 4],
	["hh", "Coupling |(t:coeff, d:0.3, s:[0,1], dval:4D)", 4],
	["hh", "Loudness |(t:coeff, d:0.7, s:[0,1], dval:B3)", 5]
];

console.log(generateDecoder(params));
