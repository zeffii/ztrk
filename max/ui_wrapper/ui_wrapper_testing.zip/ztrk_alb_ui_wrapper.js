// ztrk_alb_ui_wrapper.js
// Reusable widget library for v8ui. One UI instance per Live device.
// Usage: const uilib = require("ztrk_alb_ui_wrapper.js");

const DEFAULT_THEME = {
  bg: "#2b2b2b", panel: "#343434", text: "#bdbdbd",
  accent: "#ffad32", track: "#4a4a4a",
  font: "Arial", fontSize: 9, showHover: true, acronyms: [],
  dial: { arcStart: 2.356, arcSweep: 4.712, thickness: 3 },
};

// ---------- helpers ----------

const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

// "osc_gain" -> "Osc Gain" (acronyms upper-cased); toAttr is the exact reverse
const toLabel = (attr, acronyms = []) =>
  attr.split("_").filter(Boolean)
    .map(w => (acronyms.includes(w) ? w.toUpperCase() : w[0].toUpperCase() + w.slice(1)))
    .join(" ");
const toAttr = label => label.trim().toLowerCase().split(/\s+/).join("_");

const rgba = (hex, a = 1) => {
  let h = hex.replace("#", "");
  if (h.length === 3) h = h.split("").map(c => c + c).join("");
  const n = parseInt(h, 16);
  return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255, a];
};
const setColor = (g, hex, a = 1) => g.set_source_rgba(...rgba(hex, a));

// draw a clockwise arc between two angles regardless of order
const arcBetween = (g, cx, cy, r, a, b) => {
  if (a > b) [a, b] = [b, a];
  g.arc(cx, cy, r, a, b);
};

const fmtValue = (v, isInt, unit) => {
  const s = isInt ? `${Math.round(v)}` : `${+v.toFixed(2)}`;
  return unit ? `${s} ${unit}` : s;
};

// ---------- widget base ----------

class Widget {
  constructor(spec, ctx, ox = 0, oy = 0) {
    this.spec = spec;
    this.ctx = ctx;
    this.x = ox + (spec.x ?? 0);
    this.y = oy + (spec.y ?? 0);
    this.w = spec.w ?? 40;
    this.h = spec.h ?? 40;
    this.bind = spec.bind;
    this.interactive = false;
  }

  // lookup order: widget spec -> theme[type] -> theme -> fallback
  style(key, fallback) {
    const t = this.ctx.theme;
    const typed = typeof t[this.spec.type] === "object" ? t[this.spec.type][key] : undefined;
    return this.spec[key] ?? typed ?? t[key] ?? fallback;
  }

  get label() {
    return this.spec.label ?? (this.bind ? toLabel(this.bind, this.ctx.theme.acronyms) : "");
  }

  get hover() {
    return this.spec.hover ?? "";
  }

  contains(px, py) {
    return px >= this.x && px < this.x + this.w && py >= this.y && py < this.y + this.h;
  }

  text(g, str, cx, baseline, color) {
    g.select_font_face(this.ctx.theme.font);
    g.set_font_size(this.ctx.theme.fontSize);
    const [tw] = g.text_measure(str);
    setColor(g, color);
    g.move_to(cx - tw / 2, baseline);
    g.show_text(str);
  }

  paint(g) {}
  setValue(v) {}
  click(x, y, mods) {}
  drag(x, y, mods) {}
  release() {}
  dblclick() {}
}

// ---------- built-in widgets ----------

class Panel extends Widget {
  paint(g) {
    const th = this.ctx.theme;
    setColor(g, this.style("panel"));
    g.rectangle(this.x, this.y, this.w, this.h);
    g.fill();
    if (this.spec.title) {
      g.select_font_face(th.font);
      g.set_font_size(th.fontSize - 1);
      setColor(g, th.text, 0.6);
      g.move_to(this.x + 6, this.y + 11);
      g.show_text(this.spec.title.toUpperCase());
    }
  }
}

class Dial extends Widget {
  constructor(spec, ctx, ox, oy) {
    super(spec, ctx, ox, oy);
    this.interactive = true;
    this.min = spec.min ?? 0;
    this.max = spec.max ?? 1;
    this.isInt = !!spec.int;
    this.bipolar = !!spec.bipolar;
    this.def = spec.default ?? (this.bipolar ? (this.min + this.max) / 2 : this.min);
    this.value = this.def;
    this.dragging = false;
    this.pixels = spec.dragPixels ?? 200; // pixels of drag for full range
  }

  get norm() {
    return (this.value - this.min) / (this.max - this.min);
  }

  commit(n) {
    let v = this.min + clamp(n, 0, 1) * (this.max - this.min);
    if (this.isInt) v = Math.round(v);
    if (v === this.value) return;
    this.value = v;
    this.ctx.send(this.bind, v);
    this.ctx.redraw();
  }

  setValue(v) {
    this.value = clamp(v, this.min, this.max);
  }

  click(x, y) {
    this.dragging = true;
    this.lastY = y;
    this.cn = this.norm; // continuous position, so int dials don't lose small drags to rounding
    this.ctx.redraw();
  }

  drag(x, y, mods) {
    const factor = mods.shift ? 0.1 : 1;
    this.cn = clamp(this.cn + ((this.lastY - y) / this.pixels) * factor, 0, 1);
    this.lastY = y;
    this.commit(this.cn);
  }

  release() {
    this.dragging = false;
    this.ctx.redraw();
  }

  dblclick() {
    this.commit((this.def - this.min) / (this.max - this.min));
  }

  get hover() {
    return this.spec.hover ?? `${this.label}: ${fmtValue(this.value, this.isInt, this.spec.unit)}`;
  }

  paint(g) {
    const th = this.ctx.theme;
    const thick = this.style("thickness", 3);
    const start = this.style("arcStart", 2.356);
    const sweep = this.style("arcSweep", 4.712);
    const accent = this.style("accent");
    const labelH = this.ctx.theme.fontSize + 4;
    const d = Math.min(this.w, this.h - labelH);
    const cx = this.x + this.w / 2;
    const cy = this.y + d / 2;
    const r = d / 2 - thick;

    g.set_line_width(thick);
    g.set_line_cap("butt");

    // track
    setColor(g, this.style("track"));
    arcBetween(g, cx, cy, r, start, start + sweep);
    g.stroke();

    // value arc (from the centre for bipolar, from the start otherwise)
    const from = this.bipolar ? start + sweep / 2 : start;
    const to = start + sweep * this.norm;
    setColor(g, accent);
    if (Math.abs(to - from) > 0.001) {
      arcBetween(g, cx, cy, r, from, to);
      g.stroke();
    }

    // indicator
    g.set_line_width(2);
    g.move_to(cx + Math.cos(to) * r * 0.35, cy + Math.sin(to) * r * 0.35);
    g.line_to(cx + Math.cos(to) * r * 0.85, cy + Math.sin(to) * r * 0.85);
    g.stroke();

    // label, swapped for the value while dragging or hovered
    const showVal = this.dragging || this.ctx.hovered === this;
    const str = showVal ? fmtValue(this.value, this.isInt, this.spec.unit) : this.label;
    this.text(g, str, cx, this.y + d + th.fontSize + 1, th.text);
  }
}

// placeholder for unknown types so a bad layout entry is visible, not fatal
class Missing extends Widget {
  paint(g) {
    setColor(g, "#aa3333", 0.5);
    g.rectangle(this.x, this.y, this.w, this.h);
    g.fill();
    this.text(g, `? ${this.spec.type}`, this.x + this.w / 2, this.y + this.h / 2, "#ffffff");
  }
}

// ---------- registry ----------

const registry = { panel: Panel, dial: Dial };
const register = (type, cls) => { registry[type] = cls; };

// ---------- UI instance (one per device) ----------

class UI {
  constructor({ send, redraw }) {
    this.send = send || (() => {});
    this.redraw = redraw || (() => {});
    this.theme = DEFAULT_THEME;
    this.size = [300, 200];
    this.widgets = [];
    this.hovered = null;
    this.active = null;
  }

  load(layout) {
    const t = layout.theme || {};
    this.theme = { ...DEFAULT_THEME, ...t, dial: { ...DEFAULT_THEME.dial, ...(t.dial || {}) } };
    this.size = layout.size || this.size;
    this.widgets = [];
    this.hovered = this.active = null;
    (layout.widgets || []).forEach(spec => this.add(spec, 0, 0));
  }

  // panels flatten: children are stored with absolute coords, drawn after the panel
  add(spec, ox, oy) {
    const key = spec.type === "custom" ? spec.kind : spec.type;
    let Cls = registry[key];
    if (!Cls) {
      post(`ui: unknown widget type "${key}"\n`);
      Cls = Missing;
    }
    const w = new Cls(spec, this, ox, oy);
    this.widgets.push(w);
    (spec.children || []).forEach(c => this.add(c, w.x, w.y));
  }

  paint(g) {
    setColor(g, this.theme.bg);
    g.rectangle(0, 0, this.size[0], this.size[1]);
    g.fill();
    this.widgets.forEach(w => w.paint(g));
    if (this.theme.showHover && this.hovered && this.hovered.hover) {
      g.select_font_face(this.theme.font);
      g.set_font_size(this.theme.fontSize);
      setColor(g, this.theme.text, 0.8);
      g.move_to(6, this.size[1] - 4);
      g.show_text(this.hovered.hover);
    }
  }

  // front-to-back: last drawn widget wins
  hit(x, y) {
    for (let i = this.widgets.length - 1; i >= 0; i--) {
      const w = this.widgets[i];
      if (w.interactive && w.contains(x, y)) return w;
    }
    return null;
  }

  click(x, y, but, cmd, shift, caps, option, ctrl) {
    this.active = this.hit(x, y);
    if (this.active) this.active.click(x, y, { cmd, shift, option, ctrl });
  }

  drag(x, y, but, cmd, shift, caps, option, ctrl) {
    if (!this.active) return;
    if (!but) {
      this.active.release();
      this.active = null;
      return;
    }
    this.active.drag(x, y, { cmd, shift, option, ctrl });
  }

  dblclick(x, y) {
    const w = this.hit(x, y);
    if (w) w.dblclick();
  }

  idle(x, y) {
    const w = this.hit(x, y);
    if (w !== this.hovered) {
      this.hovered = w;
      this.redraw();
    }
  }

  idleout() {
    this.hovered = null;
    this.redraw();
  }

  // incoming value from the Ableton object / patcher (does not send back out)
  setValue(attr, v) {
    this.widgets.forEach(w => { if (w.bind === attr) w.setValue(v); });
    this.redraw();
  }
}

const create = opts => new UI(opts);

module.exports = { create, register, Widget, toLabel, toAttr, DEFAULT_THEME };
