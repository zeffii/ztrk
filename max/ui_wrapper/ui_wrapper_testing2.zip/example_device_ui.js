// example_device_ui.js — per-device v8ui script
const uilib = require("ztrk_alb_ui_wrapper.js");

mgraphics.init();
mgraphics.relative_coords = 0;
mgraphics.autofill = 0;

const ui = uilib.create({
  send: (attr, v) => outlet(0, attr, v),
  redraw: () => mgraphics.redraw(),
});

// custom widgets: uilib.register("keyboard", KeyboardClass) before loadlayout

function loadlayout(file) {
  const d = new Dict();
  d.import_json(file);
  ui.load(JSON.parse(d.stringify()));
  post(`ui: loaded ${file}, size ${ui.size[0]}x${ui.size[1]}\n`);
  mgraphics.redraw();
}

function paint() { ui.paint(mgraphics); }
function onclick(...a) { ui.click(...a); }
function ondrag(...a) { ui.drag(...a); }
function ondblclick(...a) { ui.dblclick(...a); }
function onidle(x, y) { ui.idle(x, y); }
function onidleout() { ui.idleout(); }

// incoming "<attr> <value>" messages update the widgets
function anything(...args) { ui.setValue(messagename, args[0]); }
